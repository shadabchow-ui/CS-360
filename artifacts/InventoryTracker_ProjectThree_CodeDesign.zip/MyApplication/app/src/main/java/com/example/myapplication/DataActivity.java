package com.example.myapplication;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.List;

public class DataActivity extends AppCompatActivity {

    private EditText editItemName;
    private EditText editItemQuantity;
    private EditText editItemCategory;
    private Button buttonAddItem;
    private Button buttonUpdateItem;
    private Button buttonClearSelection;
    private Button buttonGoToSms;
    private TableLayout tableInventory;

    private DatabaseHelper databaseHelper;
    private int selectedItemId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        databaseHelper = new DatabaseHelper(this);

        editItemName = findViewById(R.id.editItemName);
        editItemQuantity = findViewById(R.id.editItemQuantity);
        editItemCategory = findViewById(R.id.editItemCategory);
        buttonAddItem = findViewById(R.id.buttonAddItem);
        buttonUpdateItem = findViewById(R.id.buttonUpdateItem);
        buttonClearSelection = findViewById(R.id.buttonClearSelection);
        buttonGoToSms = findViewById(R.id.buttonGoToSms);
        tableInventory = findViewById(R.id.tableInventory);

        buttonAddItem.setOnClickListener(view -> addInventoryItem());
        buttonUpdateItem.setOnClickListener(view -> updateInventoryItem());
        buttonClearSelection.setOnClickListener(view -> clearInputFields());
        buttonGoToSms.setOnClickListener(view -> {
            Intent intent = new Intent(DataActivity.this, SmsActivity.class);
            startActivity(intent);
        });

        loadInventoryTable();
    }

    private void addInventoryItem() {
        InventoryFormData formData = readFormData();
        if (formData == null) {
            return;
        }

        long result = databaseHelper.insertInventoryItem(formData.itemName, formData.quantity, formData.category);
        if (result != -1) {
            Toast.makeText(this, R.string.item_added, Toast.LENGTH_SHORT).show();
            sendLowInventoryAlertIfNeeded(formData.itemName, formData.quantity);
            clearInputFields();
            loadInventoryTable();
        } else {
            Toast.makeText(this, R.string.item_add_failed, Toast.LENGTH_SHORT).show();
        }
    }

    private void updateInventoryItem() {
        if (selectedItemId == -1) {
            Toast.makeText(this, R.string.select_item_first, Toast.LENGTH_SHORT).show();
            return;
        }

        InventoryFormData formData = readFormData();
        if (formData == null) {
            return;
        }

        boolean success = databaseHelper.updateInventoryItem(selectedItemId, formData.itemName, formData.quantity, formData.category);
        if (success) {
            Toast.makeText(this, R.string.item_updated, Toast.LENGTH_SHORT).show();
            sendLowInventoryAlertIfNeeded(formData.itemName, formData.quantity);
            clearInputFields();
            loadInventoryTable();
        } else {
            Toast.makeText(this, R.string.item_update_failed, Toast.LENGTH_SHORT).show();
        }
    }

    private void loadInventoryTable() {
        tableInventory.removeViews(1, Math.max(0, tableInventory.getChildCount() - 1));

        List<DatabaseHelper.InventoryItem> items = databaseHelper.getAllInventoryItems();
        for (DatabaseHelper.InventoryItem item : items) {
            tableInventory.addView(createInventoryRow(item));
        }
    }

    private TableRow createInventoryRow(DatabaseHelper.InventoryItem item) {
        TableRow row = new TableRow(this);
        row.setPadding(0, 8, 0, 8);
        row.setClickable(true);

        TextView itemView = buildCell(item.getName());
        TextView quantityView = buildCell(String.valueOf(item.getQuantity()));
        TextView categoryView = buildCell(item.getCategory());

        Button deleteButton = new Button(this);
        deleteButton.setText(R.string.delete);
        deleteButton.setOnClickListener(view -> showDeleteConfirmation(item.getId(), item.getName()));

        row.addView(itemView);
        row.addView(quantityView);
        row.addView(categoryView);
        row.addView(deleteButton);

        row.setOnClickListener(view -> populateFieldsForEditing(item));
        return row;
    }

    private TextView buildCell(String value) {
        TextView textView = new TextView(this);
        textView.setPadding(16, 16, 16, 16);
        textView.setText(value);
        return textView;
    }

    private void populateFieldsForEditing(DatabaseHelper.InventoryItem item) {
        selectedItemId = item.getId();
        editItemName.setText(item.getName());
        editItemQuantity.setText(String.valueOf(item.getQuantity()));
        editItemCategory.setText(item.getCategory());
        Toast.makeText(this, R.string.item_loaded_for_editing, Toast.LENGTH_SHORT).show();
    }

    private void showDeleteConfirmation(int itemId, String itemName) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_item_title)
                .setMessage(getString(R.string.delete_item_message, itemName))
                .setPositiveButton(R.string.delete, (dialogInterface, i) -> deleteInventoryItem(itemId))
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void deleteInventoryItem(int itemId) {
        boolean success = databaseHelper.deleteInventoryItem(itemId);
        if (success) {
            if (selectedItemId == itemId) {
                clearInputFields();
            }
            Toast.makeText(this, R.string.item_deleted, Toast.LENGTH_SHORT).show();
            loadInventoryTable();
        } else {
            Toast.makeText(this, R.string.item_delete_failed, Toast.LENGTH_SHORT).show();
        }
    }

    private InventoryFormData readFormData() {
        String itemName = editItemName.getText().toString().trim();
        String quantityText = editItemQuantity.getText().toString().trim();
        String category = editItemCategory.getText().toString().trim();

        if (itemName.isEmpty() || quantityText.isEmpty() || category.isEmpty()) {
            Toast.makeText(this, R.string.fill_all_item_fields, Toast.LENGTH_SHORT).show();
            return null;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException exception) {
            Toast.makeText(this, R.string.quantity_must_be_number, Toast.LENGTH_SHORT).show();
            return null;
        }

        return new InventoryFormData(itemName, quantity, category);
    }

    private void clearInputFields() {
        selectedItemId = -1;
        editItemName.setText("");
        editItemQuantity.setText("");
        editItemCategory.setText("");
    }

    private void sendLowInventoryAlertIfNeeded(String itemName, int quantity) {
        if (quantity > 0) {
            return;
        }

        SharedPreferences preferences = getSharedPreferences(SmsActivity.PREFS_NAME, MODE_PRIVATE);
        boolean alertsEnabled = preferences.getBoolean(SmsActivity.KEY_ALERTS_ENABLED, false);
        String phoneNumber = preferences.getString(SmsActivity.KEY_PHONE_NUMBER, "");

        if (!alertsEnabled) {
            Toast.makeText(this, R.string.alert_not_enabled, Toast.LENGTH_SHORT).show();
            return;
        }

        if (phoneNumber == null || phoneNumber.trim().isEmpty()) {
            Toast.makeText(this, R.string.phone_required_for_alerts, Toast.LENGTH_SHORT).show();
            return;
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, R.string.sms_permission_missing_runtime, Toast.LENGTH_SHORT).show();
            return;
        }

        String message = getString(R.string.low_inventory_message, itemName, quantity);

        try {
            SmsManager smsManager;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                smsManager = getSystemService(SmsManager.class);
            } else {
                smsManager = SmsManager.getDefault();
            }

            if (smsManager == null) {
                Toast.makeText(this, R.string.sms_manager_unavailable, Toast.LENGTH_SHORT).show();
                return;
            }

            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, R.string.sms_sent_attempted, Toast.LENGTH_SHORT).show();
        } catch (Exception exception) {
            Toast.makeText(this, getString(R.string.sms_failed_message, exception.getMessage()), Toast.LENGTH_LONG).show();
        }
    }

    private static class InventoryFormData {
        private final String itemName;
        private final int quantity;
        private final String category;

        private InventoryFormData(String itemName, int quantity, String category) {
            this.itemName = itemName;
            this.quantity = quantity;
            this.category = category;
        }
    }
}
