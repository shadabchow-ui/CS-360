package com.example.myapplication;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    public static final String PREFS_NAME = "inventory_tracker_prefs";
    public static final String KEY_ALERTS_ENABLED = "alerts_enabled";
    public static final String KEY_PHONE_NUMBER = "phone_number";

    private TextView textPermissionStatus;
    private RadioButton radioLowInventory;
    private RadioButton radioNoAlerts;
    private RadioGroup radioNotificationOptions;
    private EditText editPhoneNumber;
    private Button buttonSaveSmsSettings;

    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                updatePermissionStatus(isGranted);
                savePreferences();
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        textPermissionStatus = findViewById(R.id.textPermissionStatus);
        radioLowInventory = findViewById(R.id.radioLowInventory);
        radioNoAlerts = findViewById(R.id.radioNoAlerts);
        radioNotificationOptions = findViewById(R.id.radioNotificationOptions);
        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        buttonSaveSmsSettings = findViewById(R.id.buttonSaveSmsSettings);

        loadSavedPreferences();
        checkSmsPermission();

        buttonSaveSmsSettings.setOnClickListener(view -> savePreferences());
        radioNotificationOptions.setOnCheckedChangeListener((group, checkedId) -> savePreferences());
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            updatePermissionStatus(true);
        } else {
            textPermissionStatus.setText(R.string.sms_permission_requesting);
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    private void updatePermissionStatus(boolean isGranted) {
        if (isGranted) {
            textPermissionStatus.setText(R.string.sms_permission_granted);
        } else {
            textPermissionStatus.setText(R.string.sms_permission_denied);
            radioNoAlerts.setChecked(true);
        }
    }

    private void loadSavedPreferences() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean alertsEnabled = preferences.getBoolean(KEY_ALERTS_ENABLED, false);
        String phoneNumber = preferences.getString(KEY_PHONE_NUMBER, "");

        editPhoneNumber.setText(phoneNumber);
        if (alertsEnabled) {
            radioLowInventory.setChecked(true);
        } else {
            radioNoAlerts.setChecked(true);
        }
    }

    private void savePreferences() {
        boolean permissionGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
        boolean alertsRequested = radioLowInventory.isChecked();
        boolean alertsEnabled = permissionGranted && alertsRequested;
        String phoneNumber = editPhoneNumber.getText().toString().trim();

        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        preferences.edit()
                .putBoolean(KEY_ALERTS_ENABLED, alertsEnabled)
                .putString(KEY_PHONE_NUMBER, phoneNumber)
                .apply();

        if (alertsRequested && !permissionGranted) {
            Toast.makeText(this, R.string.enable_permission_first, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, R.string.sms_settings_saved, Toast.LENGTH_SHORT).show();
        }
    }
}
