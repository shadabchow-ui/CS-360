package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editUsername;
    private EditText editPassword;
    private Button buttonLogin;
    private Button buttonCreateAccount;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        buttonLogin.setOnClickListener(view -> logInUser());
        buttonCreateAccount.setOnClickListener(view -> createAccount());
    }

    private void logInUser() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        if (!inputsAreValid(username, password)) {
            return;
        }

        if (databaseHelper.validateUser(username, password)) {
            Toast.makeText(this, R.string.login_success, Toast.LENGTH_SHORT).show();
            openInventoryScreen();
        } else {
            Toast.makeText(this, R.string.invalid_login, Toast.LENGTH_SHORT).show();
        }
    }

    private void createAccount() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        if (!inputsAreValid(username, password)) {
            return;
        }

        boolean success = databaseHelper.registerUser(username, password);
        if (success) {
            Toast.makeText(this, R.string.account_created, Toast.LENGTH_SHORT).show();
            openInventoryScreen();
        } else {
            Toast.makeText(this, R.string.account_exists, Toast.LENGTH_SHORT).show();
        }
    }

    private boolean inputsAreValid(String username, String password) {
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, R.string.enter_username_password, Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void openInventoryScreen() {
        Intent intent = new Intent(MainActivity.this, DataActivity.class);
        startActivity(intent);
    }
}
